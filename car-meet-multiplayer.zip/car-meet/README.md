# Car Audio Meet — multiplayer

The 3D car audio meet as an online browser game. Everyone who opens the same link
lands in the same lot and sees each other walk around, hit the hookah and chat.

- `server.js`: a small Node.js server. It serves the game page and relays players
  to each other over WebSockets. Rooms hold up to 16 players and live in memory.
- `public/index.html`: the game page.
- `public/player-model.txt`: the character model, saved as text.

## Put it online for free (Render)

You need a free **GitHub** account and a free **Render** account. Nothing runs on
your computer.

1. **Make a GitHub repo.** On github.com, click **New repository**, name it
   something like `car-meet`, set it to Public or Private, and click **Create repository**.
2. **Upload the files.** On the new repo page, click **uploading an existing file**.
   Drag in everything from this folder (`server.js`, `package.json`, `README.md`,
   `.gitignore`, and the `public` folder with both files inside), then click **Commit changes**.
   Don't upload `node_modules` if you have one.
3. **Create the service on Render.** On render.com, sign in with GitHub. Click
   **New → Web Service**, pick your `car-meet` repo, and set:
   - **Runtime:** Node
   - **Build command:** `npm install`
   - **Start command:** `npm start`
   - **Instance type:** Free
4. Click **Create Web Service**. After a minute or two you get an address like
   `https://car-meet-xxxx.onrender.com`. That's your game.

## Playing together

- Open your Render address. **MENU → PLAYER → Be the player**, then set your name in the **Online** card.
- **Copy invite link** sends friends to your room. **New private room** makes a fresh room with its own link.
- Press **Enter** to chat and **Esc** to close the chat box.

## Free plan notes

- Render puts a free service to sleep after 15 minutes with nobody connected. The
  next visitor waits about a minute while it wakes up, and after that it's instant.
- A free service gets 750 hours a month, enough to stay up all month.
- To update the game, upload the changed files to the GitHub repo. Render redeploys
  on its own.

## What's shared

- Every player parks their own car, speaker build and Medusa in their own spot in the lot.
  Everyone sees everyone's builds, and the lights and walls thump to each player's music.
- Each player plays their own music. Names show what they're playing, and the Online card
  has **Play this** for any YouTube or Spotify song someone else has on.
- You hear every player's speakers live, coming from their car and louder as you walk up. **Listen** plays
  someone's music straight to you, and **Let others hear my music** (on by default) controls sharing yours.
  It streams directly between players' browsers and nothing is uploaded or stored.
- **Play this** on someone's YouTube or Spotify song starts it on your side at the same spot and keeps you in
  sync when they pause, skip or seek.
- On phones and tablets: a thumbstick to walk, drag to look, and buttons for run, car, hookah, blunt, chat and view.
- Walking and running, hookah and blunt hits with the exhale cloud, names and chat are shared too.

## Run it yourself (optional)

```
npm install
npm start
```
Then open http://localhost:3000.
