// Car audio meet: one small server that serves the game page and relays players to each other.
// Runs anywhere Node 18+ runs (Render's free plan, for example). No database; rooms live in memory.
const http = require('http');
const fs = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 3000;
const PUB = path.join(__dirname, 'public');
const MAX_PER_ROOM = 16;
const TICK_HZ = 12;

const TYPES = { '.html': 'text/html; charset=utf-8', '.txt': 'text/plain; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon' };

// the page, with a flag that turns multiplayer on
const body = fs.readFileSync(path.join(PUB, 'index.html'), 'utf8');
const page = /<head[\s>]/i.test(body) ? body.replace(/<head([^>]*)>/i, '<head$1><script>window.DX_MP=1</script>')
  : '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><script>window.DX_MP=1</script></head><body>' + body + '</body></html>';

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname === '/favicon.ico') { res.writeHead(204); return res.end(); }
  if (url.pathname === '/healthz') { res.writeHead(200, { 'content-type': 'text/plain' }); return res.end('ok'); }
  if (url.pathname === '/' || url.pathname === '/index.html') {
    res.writeHead(200, { 'content-type': TYPES['.html'], 'cache-control': 'no-cache' });
    return res.end(page);
  }
  // other files from public/, no path tricks
  const file = path.normalize(path.join(PUB, decodeURIComponent(url.pathname)));
  if (!file.startsWith(PUB + path.sep)) { res.writeHead(403); return res.end(); }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404); return res.end('not found'); }
    res.writeHead(200, { 'content-type': TYPES[path.extname(file)] || 'application/octet-stream', 'content-length': st.size, 'cache-control': 'public, max-age=86400' });
    fs.createReadStream(file).pipe(res);
  });
});

// ---------- rooms ----------
const rooms = new Map(); // name -> Map(id -> client)
let nextId = 1;
const clean = (s, n) => String(s || '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, n);
const num = (v, lo, hi) => { v = Number(v); return Number.isFinite(v) ? Math.max(lo, Math.min(hi, v)) : 0; };
function send(ws, m) { if (ws.readyState === 1) ws.send(JSON.stringify(m)); }
function broadcast(room, m, except) { const s = JSON.stringify(m); for (const c of room.values()) if (c !== except && c.ws.readyState === 1) c.ws.send(s); }

const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 4096 });
wss.on('connection', ws => {
  const c = { ws, id: nextId++, name: 'Player', room: null, st: null, chatT: 0, msgs: 0, msgT: Date.now() };
  ws.alive = true; ws.on('pong', () => { ws.alive = true; });
  ws.on('message', raw => {
    // simple flood guard: at most 40 messages a second
    const now = Date.now(); if (now - c.msgT > 1000) { c.msgT = now; c.msgs = 0; } if (++c.msgs > 40) return;
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (!m || typeof m !== 'object') return;
    if (m.t === 'hello' && !c.room) {
      const rn = clean(m.room, 24).replace(/[^\w-]/g, '') || 'main';
      let room = rooms.get(rn); if (!room) { room = new Map(); rooms.set(rn, room); }
      if (room.size >= MAX_PER_ROOM) { send(ws, { t: 'full', max: MAX_PER_ROOM }); return ws.close(); }
      c.name = clean(m.name, 16) || 'Player' + c.id; c.room = rn; room.set(c.id, c);
      send(ws, { t: 'welcome', id: c.id, room: rn, max: MAX_PER_ROOM, players: [...room.values()].filter(o => o !== c).map(o => ({ id: o.id, name: o.name })) });
      broadcast(room, { t: 'join', id: c.id, name: c.name }, c);
      return;
    }
    const room = c.room && rooms.get(c.room); if (!room) return;
    if (m.t === 's' && Array.isArray(m.p)) {
      // position x, z (meters), facing, speed, flags
      const p = m.p; c.st = [c.id, +num(p[0], -150, 150).toFixed(3), +num(p[1], -150, 150).toFixed(3), +num(p[2], -1e3, 1e3).toFixed(3), +num(p[3], 0, 10).toFixed(2), num(p[4], 0, 255) | 0];
    } else if (m.t === 'name') {
      c.name = clean(m.name, 16) || c.name; broadcast(room, { t: 'name', id: c.id, name: c.name });
    } else if (m.t === 'chat') {
      if (now - c.chatT < 700) return; c.chatT = now;
      const msg = clean(m.m, 140); if (msg) broadcast(room, { t: 'chat', id: c.id, name: c.name, m: msg }, c);
    }
  });
  ws.on('close', () => {
    const room = c.room && rooms.get(c.room); if (!room) return;
    room.delete(c.id); broadcast(room, { t: 'leave', id: c.id });
    if (!room.size) rooms.delete(c.room);
  });
});

// everyone's latest state, a dozen times a second
setInterval(() => { for (const room of rooms.values()) { const s = [...room.values()].filter(c => c.st).map(c => c.st); if (s.length) broadcast(room, { t: 'snap', s }); } }, 1000 / TICK_HZ);
// drop connections that stopped answering
setInterval(() => { for (const ws of wss.clients) { if (!ws.alive) { ws.terminate(); continue; } ws.alive = false; ws.ping(); } }, 25000);

server.listen(PORT, () => console.log('car meet server on port ' + PORT));
