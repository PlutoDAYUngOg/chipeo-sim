// Car audio meet: one small server that serves the game page and relays players to each other.
// Runs anywhere Node 18+ runs (Render's free plan, for example). No database; rooms live in memory.
const http = require('http');
const fs = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 3000;
const PUB = path.join(__dirname, 'public');
const MAX_PER_ROOM = 8;
const TICK_HZ = 12;

const TYPES = { '.html': 'text/html; charset=utf-8', '.txt': 'text/plain; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon' };

// the page, with a flag that turns multiplayer on
const body = fs.readFileSync(path.join(PUB, 'index.html'), 'utf8');
const page = /<head[\s>]/i.test(body) ? body.replace(/<head([^>]*)>/i, '<head$1><script>window.DX_MP=1</script>')
  : '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><script>window.DX_MP=1</script></head><body>' + body + '</body></html>';

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname === '/favicon.ico') { res.writeHead(204); return res.end(); }
  if (url.pathname === '/healthz') { res.writeHead(200, { 'content-type': 'text/plain' }); return res.end('ok'); }
  if (url.pathname === '/' || url.pathname === '/index.html') {
    res.writeHead(200, { 'content-type': TYPES['.html'], 'cache-control': 'no-cache' });
    return res.end(page);
  }
  // other files from public/, no path tricks
  const file = path.normalize(path.join(PUB, decodeURIComponent(url.pathname)));
  if (!file.startsWith(PUB + path.sep)) { res.writeHead(403); return res.end(); }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404); return res.end('not found'); }
    res.writeHead(200, { 'content-type': TYPES[path.extname(file)] || 'application/octet-stream', 'content-length': st.size, 'cache-control': 'public, max-age=86400' });
    fs.createReadStream(file).pipe(res);
  });
});

// ---------- rooms ----------
const rooms = new Map(); // name -> Map(id -> client)
let nextId = 1;
const clean = (s, n) => String(s || '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, n);
const num = (v, lo, hi) => { v = Number(v); return Number.isFinite(v) ? Math.max(lo, Math.min(hi, v)) : 0; };
function send(ws, m) { if (ws.readyState === 1) ws.send(JSON.stringify(m)); }
function broadcast(room, m, except) { const s = JSON.stringify(m); for (const c of room.values()) if (c !== except && c.ws.readyState === 1) c.ws.send(s); }

const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 65536 });
wss.on('connection', ws => {
  const c = { ws, id: nextId++, name: 'Player', room: null, st: null, slot: 0, build: null, np: null, buildT: 0, chatT: 0, msgs: 0, msgT: Date.now() };
  ws.alive = true; ws.on('pong', () => { ws.alive = true; });
  ws.on('message', raw => {
    // simple flood guard: at most 120 messages a second (connecting audio to a full room sends a burst)
    const now = Date.now(); if (now - c.msgT > 1000) { c.msgT = now; c.msgs = 0; } if (++c.msgs > 120) return;
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (!m || typeof m !== 'object') return;
    if (m.t === 'hello' && !c.room) {
      const rn = clean(m.room, 24).replace(/[^\w-]/g, '') || 'main';
      let room = rooms.get(rn); if (!room) { room = new Map(); rooms.set(rn, room); }
      if (room.size >= MAX_PER_ROOM) { send(ws, { t: 'full', max: MAX_PER_ROOM }); return ws.close(); }
      // each player gets a random open parking spot, so the lot fills in naturally instead of in a line
      const used = new Set([...room.values()].map(o => o.slot)), open = []; for (let i = 0; i < MAX_PER_ROOM; i++) if (!used.has(i)) open.push(i);
      const slot = open.length ? open[0] : MAX_PER_ROOM + room.size;   // spots are listed middle-out, so taking the first open one keeps the rows even
      c.name = clean(m.name, 16) || 'Player' + c.id; c.room = rn; c.slot = slot; room.set(c.id, c);
      send(ws, { t: 'welcome', id: c.id, room: rn, slot, max: MAX_PER_ROOM, players: [...room.values()].filter(o => o !== c).map(o => ({ id: o.id, name: o.name, slot: o.slot, build: o.build, np: o.np })) });
      broadcast(room, { t: 'join', id: c.id, name: c.name, slot }, c);
      return;
    }
    const room = c.room && rooms.get(c.room); if (!room) return;
    if (m.t === 's' && Array.isArray(m.p)) {
      // position x, z (meters), facing, speed, flags
      // position x, z (meters, in the player's own spot), facing, speed, flags, bass level of their music
      const p = m.p; c.st = [c.id, +num(p[0], -150, 150).toFixed(3), +num(p[1], -150, 150).toFixed(3), +num(p[2], -1e3, 1e3).toFixed(3), +num(p[3], 0, 10).toFixed(2), num(p[4], 0, 255) | 0, num(p[5], 0, 255) | 0];
    } else if (m.t === 'build' && m.b && typeof m.b === 'object') {
      // their car, speakers and Medusa (sent when they change it; at most every 2 s)
      if (now - c.buildT < 2000) return; const txt = JSON.stringify(m.b); if (txt.length > 60000) return; c.buildT = now; c.build = m.b;
      broadcast(room, { t: 'build', id: c.id, b: m.b }, c);
    } else if (m.t === 'np') {
      // what they're playing: a title, and a YouTube/Spotify link others can play too
      const link = /^https:\/\/(www\.youtube\.com|youtu\.be|music\.youtube\.com|youtube\.com|open\.spotify\.com)\//.test(String(m.l || '')) ? String(m.l).slice(0, 300) : '';
      c.np = { n: clean(m.n, 80), l: link, p: !!m.p, pos: num(m.pos, 0, 86400), k: clean(m.k, 8) }; broadcast(room, { t: 'np', id: c.id, ...c.np }, c);
    } else if (m.t === 'rtc' && m.d && typeof m.d === 'object') {
      // audio connection setup between two players (offer, answer, network candidates), passed straight to the other one
      const to = room.get(m.to | 0); if (to && to !== c) send(to.ws, { t: 'rtc', from: c.id, d: m.d });
    } else if (m.t === 'spot') {
      // move to another parking spot, if nobody is in it
      const s = m.slot | 0; if (s < 0 || s >= MAX_PER_ROOM) return;
      if ([...room.values()].some(o => o !== c && o.slot === s)) return send(ws, { t: 'spotTaken', slot: s });
      c.slot = s; broadcast(room, { t: 'spot', id: c.id, slot: s });
    } else if (m.t === 'name') {
      c.name = clean(m.name, 16) || c.name; broadcast(room, { t: 'name', id: c.id, name: c.name });
    } else if (m.t === 'chat') {
      if (now - c.chatT < 700) return; c.chatT = now;
      const msg = clean(m.m, 140); if (msg) broadcast(room, { t: 'chat', id: c.id, name: c.name, m: msg }, c);
    }
  });
  ws.on('close', () => {
    const room = c.room && rooms.get(c.room); if (!room) return;
    room.delete(c.id); broadcast(room, { t: 'leave', id: c.id });
    if (!room.size) rooms.delete(c.room);
  });
});

// everyone's latest state, a dozen times a second
setInterval(() => { for (const room of rooms.values()) { const s = [...room.values()].filter(c => c.st).map(c => c.st); if (s.length) broadcast(room, { t: 'snap', s }); } }, 1000 / TICK_HZ);
// drop connections that stopped answering
setInterval(() => { for (const ws of wss.clients) { if (!ws.alive) { ws.terminate(); continue; } ws.alive = false; ws.ping(); } }, 25000);

server.listen(PORT, () => console.log('car meet server on port ' + PORT));
